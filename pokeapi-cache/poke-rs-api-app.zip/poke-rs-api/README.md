# Poke rs api

current routes:
- GET /
- GET /api
- GET /pkmn
- GET /html

Learn about authentication, and login screens.
- Open source auth server