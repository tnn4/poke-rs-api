use std::collections::HashMap;

// static mut id2monmap : HashMap<u64, &'static str> = HashMap::new();

pub struct Id2Pkmn {
    map: HashMap<u64, &'static str>,
}

pub struct Poke2Id {
    map: HashMap<&'static str, u64>
}

impl Poke2Id {
    pub fn new() -> Self {
        let mut m = Poke2Id {
            map: HashMap::new(),
        };
        m
    }
}

pub fn create_mappings() -> Id2Pkmn {
    let mut m = Id2Pkmn{
        map: HashMap::new(), 
    }; 
    m.map.insert(1,"bulbasaur");
    m.map.insert(6,"charizard");
    m.map.insert(25,"pikachu");
    m
}

pub fn id2pkmn(m: Id2Pkmn, id: u64) -> &'static str{
    m.map[&id]    
}

#[derive(FromPrimitive)]
pub enum PkmnEnum {
    Bulbasaur = 1,
    Ivysaur = 2,
    Venusaur = 3,
    Charmander = 4,
    Charmeleon = 5,
    Charizard = 6,
    Squirtle = 7,
    Wartortle = 8,
    Blastoise = 9,
    Pikachu = 25,
}