pub async fn get_nanoid() -> String {
    nanoid::nanoid!()
}